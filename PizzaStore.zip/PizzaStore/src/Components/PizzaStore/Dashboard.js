import React, { Component } from "react";
//import logo from "./logo.svg";
import "../../App.css";
import PropTypes from "prop-types";
import { Table, Container, Row, Col, Button } from "react-bootstrap";
import 'bootstrap/dist/css/bootstrap.min.css';
import { getPizza, addPizza, editPizza, buyPizza } from "../Redux/Action";
import { connect } from "react-redux";

class Dashboard extends Component
{
    constructor(props)
    {
        super(props);
        this.state = {
            id: 0,
            pizzaName: ""
        };
    }

    static propTypes = {
        pizzaList: PropTypes.array.isRequired,
        getPizza: PropTypes.func.isRequired,
        addPizza: PropTypes.func.isRequired,
        editPizza: PropTypes.func.isRequired,
        buyPizza: PropTypes.func.isRequired
    };

    componentDidMount()
    {
        this.props.getPizza();
    }

    submitData = () =>
    {
        if (this.state.pizzaName && !this.state.id)
        {
            const newPizza = {
                id: Math.floor(Math.random() * (999 - 100 + 1) + 100),
                pizzaName: this.state.pizzaName
            };

            this.props.addPizza(newPizza);
        }
        // } else if (this.state.pizzaName && this.state.id)
        // {
        //     const updatedDetails = {
        //         id: this.state.id,
        //         pizzaName: this.state.pizzaName
        //     };

        //     this.props.editPizza(updatedDetails);
        // } 
        else
        {
            alert("Enter Pizza Name.");
        }

        this.clearData();
    };

    // editDetails = (data) =>
    // {
    //     this.setState({
    //         id: data.id,
    //         pizzaName: data.pizzaName
    //     });
    // };

    buyPizza = (id) =>
    {
        this.clearData();
        if (window.confirm("Are you sure?"))
        {
            this.props.buyPizza(id);
        }
    };

    handleNameChange = (e) =>
    {
        this.setState({
            pizzaName: e.target.value
        });
    };

    clearData = () =>
    {
        this.setState({
            id: 0,
            pizzaName: ""
        });
    };


    render()
    {
        return (
            <div className="App">
                <Container fluid>
                    <Row noGutters>   <h1 className="App-header">Welcome to PIZZA store!</h1></Row>
                    <Row>
                        <Col style={{padding:15}}>
                            Pizza Name :{" "}
                            <input
                                onChange={this.handleNameChange}
                                value={this.state.pizzaName}
                                type="text"
                                placeholder="Pizza name"
                            />{" "}
                            <Button className="button" onClick={this.submitData}>ADD</Button>
                            <Button className="button" onClick={this.clearData}>CLEAR</Button>
                        </Col>
                        </Row>
                    <Row>
                        <Col><h4>List of available PIZZA</h4></Col>
                        <Table className="pizza-list" striped bordered hover>
                            <thead>
                                <tr>
                                        <th>ID</th>
                                        <th>Pizza Name</th>
                                        <th>Action(s)</th>
                                </tr>
                            </thead>
                            <tbody>
                                    {this.props.pizzaList &&
                                        this.props.pizzaList.map((data, index) =>
                                        {
                                            return (
                                                <tr key={index + 1}>
                                                    <td>{index + 1}</td>
                                                    <td>{data.pizzaName}</td>
                                                    <td>
                                                        <Button onClick={() => this.buyPizza(data.id)}>
                                                            BUY
                                                         </Button>{" "}
                                                    </td>
                                                </tr>
                                            );
                                        })}
                            </tbody>
                                </Table>
                            </Row>
                </Container>
            </div>
        );
    }
}

const mapStateToProps = (state) => ({
    pizzaList: state.pizzaList
});

export default connect(mapStateToProps, {
    getPizza,
    addPizza,
    editPizza,
    buyPizza
})(Dashboard);