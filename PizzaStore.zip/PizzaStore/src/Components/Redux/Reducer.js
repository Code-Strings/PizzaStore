const initialstate = {

    pizzaList: [

        { id: 1, pizzaName: "Paneer Pizza" },

        { id: 2, pizzaName: "Corn Pizza" },

        { id: 3, pizzaName: "Mexican mix-veg Pizza" }

    ]

};



const reducer = (state = initialstate, action) =>
{

    switch (action.type)
    {

        case "GET_PIZZA":

            return {

                ...state

            };

        case "ADD_PIZZA":

            return {

                ...state,

                pizzaList: state.pizzaList.concat(action.payload)

            };

        case "EDIT_PIZZA":

            return {

                ...state,

                pizzaList: state.pizzaList.map((content, i) =>

                    content.id === action.payload.id

                        ? {

                            ...content,

                            pizzaList: action.payload.pizzaList

                        }

                        : content

                )

            };

        case "BUY_PIZZA":

            return {

                ...state,

                pizzaList: state.pizzaList.filter((item) => item.id !== action.payload)

            };

        default:

            return state;

    }

};



export default reducer;