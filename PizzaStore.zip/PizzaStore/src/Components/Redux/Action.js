export function getPizza()
{
    return (dispatch) =>
    {
        return dispatch({
            type: "GET_PIZZA"
        });
    };
}

export function addPizza(data)
{
    return (dispatch) =>
    {
        return dispatch({
            type: "ADD_PIZZA",
            payload: data
        });
    };
}

export function editPizza(data)
{
    return (dispatch) =>
    {
        return dispatch({
            type: "EDIT_PIZZA",
            payload: data
        });
    };
}



export function buyPizza(pizzaId)
{
    return (dispatch) =>
    {
        return dispatch({
            type: "BUY_PIZZA",
            payload: pizzaId
        });
    };
}

